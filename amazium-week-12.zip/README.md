# Week 12: Wishlist

## Previous Progress
With the payment systems live as of Week 11, the project reached its core functional peak.

## Current Project State (Week 12)
In this week, we focused on implementing:
- **'Save for Later' Wishlist**: Ability for users to bookmark products they aren't ready to buy yet.
- **Recommendation Engine**: Rule-based (or AI-driven) suggestions based on browsing and purchase history.
- **Wishlist to Cart Flow**: Easy one-click transfers from the wishlist to the shopping cart.
- **Personalized Home Feed**: Dynamic sections showing 'Recommended for You' products.

The project now supports proactively helping users find what they love, driving higher engagement.

## Future Expectations (Week 13)
Next week, we plan to implement: **Notifications & Order Tracking**

## Student Information
- **Name**: abdelrahman hamdy
- **ID**: 202002570
